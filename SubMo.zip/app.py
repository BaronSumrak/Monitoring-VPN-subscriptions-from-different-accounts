"""SubMonitor - контроль срока действия VPN-подписок по ссылке-подписке."""
import copy
import datetime as dt
import json
import logging
import os
import queue
import re
import threading
import tkinter as tk
import uuid
from tkinter import messagebox, ttk

import requests

APP_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "SubMonitor")
os.makedirs(APP_DIR, exist_ok=True)
CFG_PATH = os.path.join(APP_DIR, "config.json")

# В режиме --noconsole у программы нет stderr, поэтому пишем логи в файл
logging.basicConfig(filename=os.path.join(APP_DIR, "submonitor.log"), level=logging.WARNING,
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s", encoding="utf-8")

DEFAULT_REGEX = r"(\d{2}\.\d{2}\.\d{4})"
DEFAULT_DATEFMT = "%d.%m.%Y"

THEMES = {
    "dark": dict(bg="#13151a", surface="#1b1e25", surface2="#252a36", border="#333a4c",
                 fg="#e7e9ef", muted="#8b93a7", accent="#5b8cff", accent_hover="#7aa2ff",
                 accent_fg="#ffffff", ok="#3ecf8e", warn="#f5a524", bad="#ff6b6b", select="#2b3550"),
    "light": dict(bg="#f3f5f9", surface="#ffffff", surface2="#eef1f6", border="#d5dbe8",
                  fg="#1d2330", muted="#667085", accent="#3d6df2", accent_hover="#2f5bd6",
                  accent_fg="#ffffff", ok="#17935f", warn="#b86e00", bad="#d13b3b", select="#dfe8ff"),
}
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI Semibold", 20)
FONT_SMALL_BOLD = ("Segoe UI", 8, "bold")
FONT_MONO = ("Consolas", 9)

# (подпись, ключ, подсказка); ключ None - заголовок раздела формы
SUB_FIELDS = [
    ("Подписка", None),
    ("Название", "name"),
    ("Ссылка подписки", "url"),
    ("Разбор даты (необязательно)", None),
    ("Шаблон (regex)", "regex"),
    ("Формат даты", "datefmt"),
]
SUB_KEYS = ("name", "url", "regex", "datefmt")


def new_sub(n=1):
    return {"id": uuid.uuid4().hex[:8], "name": f"Подписка {n}", "url": "",
            "regex": DEFAULT_REGEX, "datefmt": DEFAULT_DATEFMT}


def describe(e):
    """Понятное описание ошибки (у TimeoutError текст пустой)."""
    if isinstance(e, TimeoutError) or type(e).__name__ == "TimeoutError":
        return "нет ответа (таймаут)"
    return str(e) or type(e).__name__


def load_cfg():
    cfg = {"remind_days": 3, "interval_hours": 12, "popup": True,
           "subs": [], "last_notified": {}, "theme": "dark"}
    if os.path.exists(CFG_PATH):
        try:
            with open(CFG_PATH, encoding="utf-8") as f:
                data = json.load(f)
            subs = data.pop("subs", None)
            old_accounts = data.pop("accounts", None)  # конфиг старой версии
            cfg.update({k: v for k, v in data.items() if k in cfg})
            if isinstance(subs, list):
                cfg["subs"] = [{**new_sub(i + 1), **s} for i, s in enumerate(subs)]
            elif isinstance(old_accounts, list):
                # переносим из старой версии только VPN-подписки
                for a in old_accounts:
                    if a.get("mode") == "vpn" and a.get("vpn_url"):
                        cfg["subs"].append({**new_sub(len(cfg["subs"]) + 1), "name": a.get("name", ""),
                                            "url": a["vpn_url"],
                                            "regex": a.get("regex") or DEFAULT_REGEX,
                                            "datefmt": a.get("datefmt") or DEFAULT_DATEFMT})
        except Exception:
            # повреждённый конфиг не затираем молча - сохраняем копию
            try:
                os.replace(CFG_PATH, CFG_PATH + ".bak")
            except OSError:
                pass
    if not cfg["subs"]:
        cfg["subs"] = [new_sub(1)]
    return cfg


def save_cfg(cfg):
    tmp = CFG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CFG_PATH)  # атомарная запись: файл не повредится при сбое


def parse_expiry(text, sub):
    m = re.search(sub.get("regex") or DEFAULT_REGEX, text)
    if not m:
        return None
    raw = m.group(1) if m.re.groups else m.group(0)
    return dt.datetime.strptime(raw, sub.get("datefmt") or DEFAULT_DATEFMT).date()


def fetch_vpn(sub):
    """Срок подписки по ссылке-подписке VPN (Marzban, Hiddify, 3x-ui, Remnawave и т.п.).
    Возвращает (дата окончания или None, текст с описанием)."""
    url = sub.get("url", "").strip()
    if not re.match(r"^https?://", url, re.I):
        raise ValueError("нужна ссылка подписки (https://...), а не ключ vless:// / vmess:// / ss:// - "
                         "в самом ключе срока действия нет")
    try:
        r = requests.get(url, headers={"User-Agent": "v2rayN/6.42"}, timeout=20)
        r.raise_for_status()
    except requests.HTTPError as e:
        # from None - чтобы ссылка с токеном не попала в текст ошибки и лог
        raise RuntimeError(f"сервер ответил {e.response.status_code}") from None
    except requests.RequestException as e:
        raise RuntimeError(f"сеть: {type(e).__name__}") from None

    info = dict(re.findall(r"(\w+)\s*=\s*(\d+)", r.headers.get("subscription-userinfo", "")))
    parts = []
    if info:
        used = int(info.get("upload", 0)) + int(info.get("download", 0))
        total = int(info.get("total", 0))
        parts.append(f"трафик {used / 1e9:.1f} из {total / 1e9:.1f} ГБ" if total
                     else f"трафик {used / 1e9:.1f} ГБ (без лимита)")
    extra = "; ".join(parts)

    if "expire" in info:
        ts = int(info["expire"])
        if ts == 0:
            return None, "; ".join(parts + ["срок не ограничен"])
        return dt.datetime.fromtimestamp(ts).date(), extra

    # запасные варианты: JSON-ответ панели или дата в тексте
    try:
        data = r.json()
    except ValueError:
        data = None
    if isinstance(data, dict):
        for k in ("expire", "expire_date", "expiry", "expiryTime", "expired_at"):
            val = data.get(k)
            if isinstance(val, (int, float)) and val > 0:
                return dt.datetime.fromtimestamp(val / 1000 if val > 1e12 else val).date(), extra
            if isinstance(val, str) and val:
                try:
                    return dt.datetime.fromisoformat(val.replace("Z", "+00:00")).date(), extra
                except ValueError:
                    pass
    try:
        exp = parse_expiry(r.text, sub)
    except Exception:
        exp = None
    if exp:
        return exp, extra
    raise ValueError("сервер не вернул срок подписки (нет заголовка Subscription-Userinfo). "
                     "Возможно, этот сервис не отдаёт срок по ссылке")


# ---------- Интерфейс ----------
class App:
    def __init__(self, root):
        self.root = root
        self.cfg = load_cfg()
        self.lock = threading.Lock()
        self.q = queue.Queue()
        self.busy = False
        self.auto_id = None      # id таймера автопроверки
        self.sel = None          # id выбранной подписки
        self.rows = {}           # id -> (дата, дней, статус)
        self.theme = self.cfg.get("theme") if self.cfg.get("theme") in THEMES else "dark"
        self.fv = {k: tk.StringVar() for k in SUB_KEYS}
        self.g = {"remind_days": tk.StringVar(value=str(self.cfg["remind_days"])),
                  "interval_hours": tk.StringVar(value=str(self.cfg["interval_hours"]))}
        self.popup_var = tk.BooleanVar(value=bool(self.cfg["popup"]))
        self.build_ui()
        self.apply_theme()
        self.fix_shortcuts()
        for sub in self.cfg["subs"]:
            self.rows[sub["id"]] = ("-", "-", "не проверялось")
            self.tree.insert("", "end", iid=sub["id"])
            self.render_row(sub["id"])
        self.tree.selection_set(self.cfg["subs"][0]["id"])
        root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.pump()
        self.auto_id = self.root.after(5000, self.auto)

    # --- оформление ---
    def build_ui(self):
        root = self.root
        root.title("SubMonitor - подписки")
        root.geometry("1120x700")
        root.minsize(1000, 620)
        self.style = ttk.Style()
        self.style.theme_use("clam")  # единственная тема ttk, которая позволяет менять цвета

        header = ttk.Frame(root)
        header.pack(fill="x", padx=22, pady=(16, 10))
        ttk.Label(header, text="SubMonitor", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="контроль срока VPN-подписок",
                  style="Muted.TLabel").pack(side="left", padx=(14, 0), pady=(10, 0))
        self.theme_btn = ttk.Button(header, style="Ghost.TButton", command=self.toggle_theme)
        self.theme_btn.pack(side="right")

        body = ttk.Frame(root)
        body.pack(fill="both", expand=True, padx=22, pady=(0, 18))
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # левая колонка: настройки
        left = ttk.Frame(body)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 18))
        ttk.Button(left, text="Сохранить настройки", command=self.save).pack(side="bottom", fill="x", pady=(12, 0))
        self.nb = ttk.Notebook(left)
        self.nb.pack(side="top", fill="both", expand=True)
        self.build_sub_tab()
        self.build_schedule_tab()

        # правая колонка: статус и журнал
        right = ttk.Frame(body)
        right.grid(row=0, column=1, sticky="nsew")

        top = ttk.Frame(right)
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Подписки", style="Heading.TLabel").pack(side="left")
        ttk.Button(top, text="Проверить сейчас", style="Accent.TButton",
                   command=self.check_now).pack(side="right")
        ttk.Button(top, text="Удалить", command=self.remove_sub).pack(side="right", padx=(0, 8))
        ttk.Button(top, text="+ Добавить", command=self.add_sub).pack(side="right", padx=(0, 8))

        cols = ("name", "exp", "left", "st")
        self.tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse", height=8)
        for c, t, w, anc in zip(cols, ("Подписка", "Действует до", "Дней", "Статус"),
                                (170, 120, 70, 260), ("w", "w", "center", "w")):
            self.tree.heading(c, text=t, anchor=anc)
            self.tree.column(c, width=w, anchor=anc, stretch=(c == "st"))
        self.tree.pack(fill="x")
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        ttk.Label(right, text="Журнал", style="Heading.TLabel").pack(anchor="w", pady=(18, 8))
        logfr = ttk.Frame(right)
        logfr.pack(fill="both", expand=True)
        self.logbox = tk.Text(logfr, height=10, state="disabled", wrap="word")
        sb = ttk.Scrollbar(logfr, command=self.logbox.yview)
        self.logbox.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.logbox.pack(side="left", fill="both", expand=True)

    def build_sub_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=(18, 14))
        tab.columnconfigure(0, minsize=165)
        tab.columnconfigure(1, weight=1)
        self.nb.add(tab, text="Подписка")
        r = 0
        for label, key in SUB_FIELDS:
            if key is None:  # заголовок раздела
                ttk.Label(tab, text=label.upper(), style="Section.TLabel").grid(
                    row=r, column=0, columnspan=2, sticky="w", pady=(0 if r == 0 else 12, 2))
                r += 1
                continue
            ttk.Label(tab, text=label, style="Card.TLabel").grid(row=r, column=0, sticky="w", pady=3, padx=(0, 14))
            ttk.Entry(tab, textvariable=self.fv[key], width=34).grid(row=r, column=1, sticky="ew", pady=3)
            r += 1
        ttk.Label(tab, style="CardMuted.TLabel", justify="left", wraplength=380,
                  text="Нужна ссылка подписки вида https://..., которую выдаёт ваш VPN-сервис. "
                       "Срок берётся из ответа сервера. Поля «Шаблон» и «Формат даты» нужны только "
                       "если сервис отдаёт дату текстом."
                  ).grid(row=r, column=0, columnspan=2, sticky="w", pady=(16, 0))

    def build_schedule_tab(self):
        tab = ttk.Frame(self.nb, style="Card.TFrame", padding=(18, 14))
        tab.columnconfigure(0, minsize=165)
        tab.columnconfigure(1, weight=1)
        self.nb.add(tab, text="Расписание")
        ttk.Label(tab, text="РАСПИСАНИЕ", style="Section.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 2))
        for r, (label, key) in enumerate((("Напоминать за (дней)", "remind_days"),
                                          ("Проверять каждые (часов)", "interval_hours")), start=1):
            ttk.Label(tab, text=label, style="Card.TLabel").grid(row=r, column=0, sticky="w", pady=3, padx=(0, 14))
            ttk.Entry(tab, textvariable=self.g[key], width=34).grid(row=r, column=1, sticky="ew", pady=3)
        ttk.Checkbutton(tab, text="Показывать окно-напоминание", variable=self.popup_var,
                        style="Card.TCheckbutton").grid(row=3, column=0, columnspan=2, sticky="w", pady=(10, 0))
        ttk.Label(tab, style="CardMuted.TLabel", justify="left", wraplength=380,
                  text="Окно появляется не чаще раза в сутки для каждой подписки, пока до конца "
                       "срока осталось не больше указанного числа дней. Программа должна быть запущена."
                  ).grid(row=4, column=0, columnspan=2, sticky="w", pady=(16, 0))

    def apply_theme(self):
        t, st = THEMES[self.theme], self.style
        self.root.configure(bg=t["bg"])
        st.configure(".", background=t["bg"], foreground=t["fg"], font=FONT, bordercolor=t["border"],
                     lightcolor=t["border"], darkcolor=t["border"], troughcolor=t["surface2"],
                     focuscolor=t["bg"], insertcolor=t["fg"])
        # контейнеры и подписи
        st.configure("TFrame", background=t["bg"])
        st.configure("Card.TFrame", background=t["surface"])
        st.configure("TLabel", background=t["bg"], foreground=t["fg"])
        st.configure("Card.TLabel", background=t["surface"], foreground=t["fg"])
        st.configure("Muted.TLabel", background=t["bg"], foreground=t["muted"])
        st.configure("CardMuted.TLabel", background=t["surface"], foreground=t["muted"])
        st.configure("Section.TLabel", background=t["surface"], foreground=t["accent"], font=FONT_SMALL_BOLD)
        st.configure("Title.TLabel", background=t["bg"], foreground=t["fg"], font=FONT_TITLE)
        st.configure("Heading.TLabel", background=t["bg"], foreground=t["fg"], font=("Segoe UI Semibold", 12))
        st.configure("Card.TCheckbutton", background=t["surface"], foreground=t["fg"], focuscolor=t["surface"])
        st.map("Card.TCheckbutton", background=[("active", t["surface"])], foreground=[("active", t["fg"])])
        # поля ввода
        st.configure("TEntry", fieldbackground=t["surface2"], foreground=t["fg"], bordercolor=t["border"],
                     lightcolor=t["surface2"], darkcolor=t["surface2"], insertcolor=t["fg"], padding=6)
        st.map("TEntry",
               bordercolor=[("focus", t["accent"]), ("disabled", t["surface"])],
               lightcolor=[("focus", t["accent"]), ("disabled", t["surface"])],
               darkcolor=[("focus", t["accent"]), ("disabled", t["surface"])],
               fieldbackground=[("disabled", t["surface"])], foreground=[("disabled", t["muted"])])
        # кнопки
        st.configure("TButton", background=t["surface2"], foreground=t["fg"], bordercolor=t["border"],
                     lightcolor=t["surface2"], darkcolor=t["surface2"], padding=(14, 8), relief="flat",
                     focusthickness=0, font=FONT)
        st.map("TButton", background=[("disabled", t["surface"]), ("active", t["border"])],
               foreground=[("disabled", t["muted"])], bordercolor=[("disabled", t["border"])])
        st.configure("Accent.TButton", background=t["accent"], foreground=t["accent_fg"], bordercolor=t["accent"],
                     lightcolor=t["accent"], darkcolor=t["accent"], padding=(18, 8), font=FONT_BOLD)
        st.map("Accent.TButton", background=[("disabled", t["border"]), ("active", t["accent_hover"])],
               bordercolor=[("active", t["accent_hover"])], lightcolor=[("active", t["accent_hover"])],
               darkcolor=[("active", t["accent_hover"])], foreground=[("disabled", t["muted"])])
        st.configure("Ghost.TButton", background=t["bg"], foreground=t["muted"], bordercolor=t["bg"],
                     lightcolor=t["bg"], darkcolor=t["bg"], padding=(10, 6))
        st.map("Ghost.TButton", background=[("active", t["surface2"])], foreground=[("active", t["fg"])],
               bordercolor=[("active", t["surface2"])], lightcolor=[("active", t["surface2"])],
               darkcolor=[("active", t["surface2"])])
        # вкладки
        st.configure("TNotebook", background=t["bg"], borderwidth=0, tabmargins=(0, 0, 0, 0),
                     bordercolor=t["border"], lightcolor=t["surface"], darkcolor=t["surface"])
        st.configure("TNotebook.Tab", background=t["bg"], foreground=t["muted"], padding=(14, 9),
                     borderwidth=0, font=FONT, lightcolor=t["bg"], darkcolor=t["bg"], bordercolor=t["bg"])
        st.map("TNotebook.Tab", background=[("selected", t["surface"])], foreground=[("selected", t["fg"])],
               lightcolor=[("selected", t["surface"])], darkcolor=[("selected", t["surface"])],
               bordercolor=[("selected", t["surface"])], expand=[("selected", (0, 0, 0, 0))])
        # таблица
        st.configure("Treeview", background=t["surface"], fieldbackground=t["surface"], foreground=t["fg"],
                     rowheight=36, borderwidth=0, bordercolor=t["border"], lightcolor=t["surface"],
                     darkcolor=t["surface"], font=FONT)
        st.map("Treeview", background=[("selected", t["select"])], foreground=[("selected", t["fg"])])
        st.configure("Treeview.Heading", background=t["surface2"], foreground=t["muted"], relief="flat",
                     padding=(10, 9), font=("Segoe UI", 9, "bold"), bordercolor=t["surface2"],
                     lightcolor=t["surface2"], darkcolor=t["surface2"])
        st.map("Treeview.Heading", background=[("active", t["surface2"])])
        self.tree.tag_configure("ok", foreground=t["ok"])
        self.tree.tag_configure("warn", foreground=t["warn"])
        self.tree.tag_configure("bad", foreground=t["bad"])
        self.tree.tag_configure("idle", foreground=t["muted"])
        # прокрутка
        st.configure("Vertical.TScrollbar", background=t["surface2"], troughcolor=t["bg"], bordercolor=t["bg"],
                     arrowcolor=t["muted"], lightcolor=t["surface2"], darkcolor=t["surface2"], gripcount=0)
        st.map("Vertical.TScrollbar", background=[("active", t["border"])])
        # журнал (обычный tk.Text, ttk-стили на него не действуют)
        self.logbox.config(bg=t["surface"], fg=t["fg"], insertbackground=t["fg"], selectbackground=t["select"],
                           relief="flat", highlightthickness=1, highlightbackground=t["border"],
                           highlightcolor=t["border"], padx=12, pady=10, font=FONT_MONO)
        self.logbox.tag_configure("ts", foreground=t["muted"])
        self.logbox.tag_configure("err", foreground=t["bad"])
        self.logbox.tag_configure("ok", foreground=t["ok"])
        self.theme_btn.config(text="☀  Светлая тема" if self.theme == "dark" else "☾  Тёмная тема")

    def toggle_theme(self):
        self.theme = "light" if self.theme == "dark" else "dark"
        self.apply_theme()
        with self.lock:
            self.cfg["theme"] = self.theme
            save_cfg(self.cfg)

    def fix_shortcuts(self):
        """Ctrl+C/V/X в Tk не работают при русской раскладке - добавляем их по коду клавиши."""
        def handler(e):
            if e.keysym.lower() in ("v", "c", "x", "a"):  # латиница уже обработана самим Tk
                return None
            w = e.widget
            if e.keycode == 86:
                w.event_generate("<<Paste>>")
            elif e.keycode == 67:
                w.event_generate("<<Copy>>")
            elif e.keycode == 88:
                w.event_generate("<<Cut>>")
            elif e.keycode == 65 and isinstance(w, (ttk.Entry, tk.Entry)):
                w.selection_range(0, "end")
                return "break"
            return None
        self.root.bind_all("<Control-KeyPress>", handler)

    # --- потокобезопасные обновления интерфейса ---
    def post(self, fn, *args):
        """Выполнить fn(*args) в главном потоке Tk (можно вызывать из любого потока)."""
        self.q.put((fn, args))

    def pump(self):
        try:
            while True:
                fn, args = self.q.get_nowait()
                try:
                    fn(*args)
                except Exception:
                    logging.exception("ui callback error")
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    def log(self, text):
        self.post(self._log, text)

    def _log(self, text):
        low = text.lower()
        if "ошибка" in low or "сбой" in low or "не найдена" in low or "истекла" in low:
            tag = "err"
        elif "сохранен" in low:
            tag = "ok"
        else:
            tag = ""
        self.logbox.config(state="normal")
        self.logbox.insert("end", f"{dt.datetime.now():%H:%M:%S}  ", "ts")
        self.logbox.insert("end", f"{text}\n", tag)
        self.logbox.see("end")
        self.logbox.config(state="disabled")

    # --- список подписок ---
    def find(self, sid):
        for s in self.cfg["subs"]:
            if s["id"] == sid:
                return s
        return None

    def render_row(self, sid):
        sub = self.find(sid)
        if sub is None or not self.tree.exists(sid):
            return
        exp, left, status = self.rows.get(sid, ("-", "-", ""))
        low = str(status).lower()
        if low.startswith("ошибка") or "истекла" in low or "не найдена" in low:
            tag, dot = "bad", "●"
        elif low.startswith("скоро") or "последний" in low:
            tag, dot = "warn", "●"
        elif low == "ок":
            tag, dot = "ok", "●"
        else:
            tag, dot = "idle", "○"
        self.tree.item(sid, values=(sub["name"], exp, left, f"{dot}  {status}"), tags=(tag,))

    def set_row(self, sid, exp, left, status):
        self.rows[sid] = (exp, left, status)
        self.render_row(sid)

    def load_form(self):
        sub = self.find(self.sel) if self.sel else None
        for k in SUB_KEYS:
            self.fv[k].set(sub[k] if sub else "")

    def apply_form(self):
        """Переносит значения из формы в выбранную подписку."""
        sub = self.find(self.sel) if self.sel else None
        if sub is None:
            return
        with self.lock:
            for k in SUB_KEYS:
                sub[k] = self.fv[k].get().strip()
            if not sub["name"]:
                sub["name"] = "Подписка"
        self.render_row(sub["id"])

    def on_select(self, _=None):
        cur = self.tree.selection()
        new = cur[0] if cur else None
        if new == self.sel:
            return
        self.apply_form()  # не теряем несохранённые правки предыдущей подписки
        self.sel = new
        self.load_form()

    def add_sub(self):
        self.apply_form()
        with self.lock:
            sub = new_sub(len(self.cfg["subs"]) + 1)
            self.cfg["subs"].append(sub)
        self.rows[sub["id"]] = ("-", "-", "не проверялось")
        self.tree.insert("", "end", iid=sub["id"])
        self.render_row(sub["id"])
        self.tree.selection_set(sub["id"])
        self.nb.select(0)

    def remove_sub(self):
        sid = self.sel
        sub = self.find(sid) if sid else None
        if sub is None:
            return
        if not messagebox.askyesno("Удалить", f"Удалить «{sub['name']}»?", parent=self.root):
            return
        self.sel = None
        with self.lock:
            self.cfg["subs"] = [s for s in self.cfg["subs"] if s["id"] != sid]
            self.cfg["last_notified"].pop(sid, None)
            if not self.cfg["subs"]:
                self.cfg["subs"].append(new_sub(1))
                fresh = self.cfg["subs"][0]
                self.rows[fresh["id"]] = ("-", "-", "не проверялось")
                self.tree.insert("", "end", iid=fresh["id"])
                self.render_row(fresh["id"])
            save_cfg(self.cfg)
        self.rows.pop(sid, None)
        self.tree.delete(sid)
        self.tree.selection_set(self.cfg["subs"][0]["id"])
        self.log(f"Удалено: {sub['name']}")

    # --- настройки ---
    def save(self, quiet=False):
        """Сохраняет настройки. Возвращает True, если всё корректно."""
        gv = {k: v.get().strip() for k, v in self.g.items()}
        for key, label, minimum in (("remind_days", "Напоминать за (дней)", 0),
                                    ("interval_hours", "Проверять каждые (часов)", 1)):
            if not gv[key].isdigit() or int(gv[key]) < minimum:
                messagebox.showwarning("Настройки", f"Поле «{label}» должно быть целым числом ≥ {minimum}",
                                       parent=self.root)
                return False
        self.apply_form()
        with self.lock:
            old_interval = self.cfg.get("interval_hours")
            self.cfg["remind_days"] = int(gv["remind_days"])
            self.cfg["interval_hours"] = int(gv["interval_hours"])
            self.cfg["popup"] = bool(self.popup_var.get())
            save_cfg(self.cfg)
        if old_interval != int(gv["interval_hours"]):
            self.schedule_auto()  # новый интервал действует сразу
        if not quiet:
            self.log("Настройки сохранены")
        return True

    # --- проверка ---
    def check_now(self):
        if not self.save(quiet=True):
            return
        if self.busy:
            self.log("Проверка уже выполняется")
        self.start_check()

    def start_check(self):
        if self.busy:
            return
        self.busy = True
        threading.Thread(target=self.worker, daemon=True).start()

    def worker(self):
        try:
            with self.lock:
                cfg = copy.deepcopy(self.cfg)
            today = dt.date.today()
            remind = cfg["remind_days"]
            alerts = []
            for sub in cfg["subs"]:
                sid, name = sub["id"], sub["name"]
                if not sub["url"]:
                    self.post(self.set_row, sid, "-", "-", "нет ссылки")
                    continue
                try:
                    exp, text = fetch_vpn(sub)
                except Exception as e:
                    logging.exception("fetch error")
                    self.post(self.set_row, sid, "-", "-", f"ошибка: {describe(e)}")
                    self.log(f"[{name}] ошибка: {describe(e)}")
                    continue
                if not exp:
                    if "не ограничен" in text:
                        self.post(self.set_row, sid, "-", "-", "без срока")
                        self.log(f"[{name}] {text}")
                    else:
                        self.post(self.set_row, sid, "-", "-", "дата не найдена")
                        self.log(f"[{name}] дата не найдена")
                    continue
                left = (exp - today).days
                if left < 0:
                    status = "ИСТЕКЛА"
                elif left == 0:
                    status = "последний день"
                elif left <= remind:
                    status = "скоро конец"
                else:
                    status = "ок"
                self.post(self.set_row, sid, exp.strftime("%d.%m.%Y"), left, status)
                tail = f"; {text}" if text else ""
                self.log(f"[{name}] до {exp:%d.%m.%Y}, осталось {left} дн.{tail}")

                if left <= remind and cfg["popup"] and cfg["last_notified"].get(sid) != str(today):
                    when = "истекла" if left < 0 else ("заканчивается сегодня" if left == 0
                                                       else f"заканчивается {exp:%d.%m.%Y} (через {left} дн.)")
                    alerts.append(f"• {name}: подписка {when}")
                    cfg["last_notified"][sid] = str(today)
                    with self.lock:
                        self.cfg["last_notified"][sid] = str(today)
                        save_cfg(self.cfg)
            if alerts:
                self.post(self.notify, alerts)
        except Exception as e:
            logging.exception("worker error")
            self.log(f"Сбой проверки: {describe(e)}")
        finally:
            self.busy = False

    def notify(self, lines):
        """Окно-напоминание поверх остальных окон."""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.attributes("-topmost", False)
        except tk.TclError:
            pass
        messagebox.showwarning("SubMonitor: пора продлить подписку", "\n".join(lines), parent=self.root)

    def auto(self):
        self.start_check()
        self.schedule_auto()

    def schedule_auto(self):
        """(Пере)запускает таймер автопроверки с текущим интервалом."""
        if self.auto_id is not None:
            try:
                self.root.after_cancel(self.auto_id)
            except Exception:
                pass
        try:
            hours = max(1, int(self.cfg.get("interval_hours", 12)))
        except (TypeError, ValueError):
            hours = 12
        self.auto_id = self.root.after(hours * 3600 * 1000, self.auto)

    def on_close(self):
        try:  # сохраняем несохранённые правки формы
            self.apply_form()
            with self.lock:
                save_cfg(self.cfg)
        except Exception:
            logging.exception("save on close")
        self.root.destroy()


if __name__ == "__main__":
    try:  # чёткий (не размытый) интерфейс на экранах с масштабированием
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()
