@echo off
cd /d "%~dp0"
echo === Building SubMonitor ===

rem --- Find Python: py launcher first, then python (Microsoft Store stub is rejected) ---
set "PY="
where py >nul 2>nul && py -3 --version >nul 2>nul && set "PY=py -3"
if not defined PY (
    where python >nul 2>nul && python --version >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo Python not found. Install it from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add python.exe to PATH" and "tcl/tk and IDLE" in the installer.
    echo Then run this file again.
    pause
    exit /b 1
)
echo Using: %PY%

if not exist app.py (
    echo app.py not found next to build.bat. Rename your file to app.py.
    pause
    exit /b 1
)


%PY% -m pip install --upgrade pip
%PY% -m pip install requests pyinstaller
if errorlevel 1 (
    echo Failed to install dependencies. Check your internet connection and the error above.
    pause
    exit /b 1
)

if exist dist\SubMonitor.exe del /q dist\SubMonitor.exe
if exist SubMonitor.exe del /q SubMonitor.exe
if exist SubMonitor.exe (
    echo Cannot delete old SubMonitor.exe - close the program and try again.
    pause
    exit /b 1
)

%PY% -m PyInstaller --noconfirm --clean --noconsole --onefile --name SubMonitor app.py

if exist dist\SubMonitor.exe (
    copy /y dist\SubMonitor.exe "%~dp0SubMonitor.exe" >nul
    if exist build rmdir /s /q build
    if exist SubMonitor.spec del /q SubMonitor.spec
    echo.
    echo DONE: SubMonitor.exe is next to this file.
    echo Settings and logs are stored in %%APPDATA%%\SubMonitor
) else (
    echo.
    echo Build failed. Send me the error text above.
    pause
    exit /b 1
)
pause
